/**
 * tests/unit/fingerprint.test.ts
 *
 * Unit tests for server/fingerprint.ts — the core matching algorithm.
 * All functions are pure (no I/O), so tests run fast with zero mocks.
 *
 * Coverage goals:
 *   ✓ Tag weighting tiers (rare/uncommon/common/unclassified)
 *   ✓ buildFingerprint: photo tags, adventure tags, normalisation, priority rules
 *   ✓ computeOverlap: score range, symmetry, edge cases, shared tag list
 *   ✓ detectAlmostMet: location matching, year proximity, no false positives
 *   ✓ computeHonestyTier: verdict ratio thresholds, authenticity score thresholds
 */

import { describe, it, expect } from "vitest";
import {
  buildFingerprint,
  computeOverlap,
  detectAlmostMet,
  computeHonestyTier,
} from "../../server/fingerprint";
import { makePhoto, makePhotoWithLocation } from "../fixtures/factories";

const USER_A = "user-a-id";
const USER_B = "user-b-id";

// ---------------------------------------------------------------------------
// buildFingerprint
// ---------------------------------------------------------------------------

describe("buildFingerprint", () => {
  it("returns an empty map when user has no photos and no tags", () => {
    const fp = buildFingerprint([], null);
    expect(fp.size).toBe(0);
  });

  it("returns an empty map when photos exist but have no tags", () => {
    const photo = makePhoto(USER_A, { tags: [] });
    const fp = buildFingerprint([photo], null);
    expect(fp.size).toBe(0);
  });

  it("accumulates weights from photo tags across multiple photos", () => {
    const photos = [
      makePhoto(USER_A, { tags: ["hiking"], adventureScore: 0 }),
      makePhoto(USER_A, { tags: ["hiking"], adventureScore: 0 }),
    ];
    const fp = buildFingerprint(photos, null);
    // Each 'hiking' (common) = weight 1.0 × (1 + 0/200) = 1.0; total = 2.0
    expect(fp.get("hiking")).toBeCloseTo(2.0, 5);
  });

  it("applies higher weight to rare tags than common tags", () => {
    const photos = [
      makePhoto(USER_A, { tags: ["skydiving", "hiking"], adventureScore: 0 }),
    ];
    const fp = buildFingerprint(photos, null);
    expect(fp.get("skydiving")!).toBeGreaterThan(fp.get("hiking")!);
    expect(fp.get("skydiving")).toBeCloseTo(4.0, 5); // rare = 4
    expect(fp.get("hiking")).toBeCloseTo(1.0, 5);     // common = 1
  });

  it("applies higher weight to uncommon tags than common tags", () => {
    const photos = [
      makePhoto(USER_A, { tags: ["snowboarding", "walking"], adventureScore: 0 }),
    ];
    const fp = buildFingerprint(photos, null);
    expect(fp.get("snowboarding")!).toBeGreaterThan(fp.get("walking")!);
    expect(fp.get("snowboarding")).toBeCloseTo(2.5, 5);
    expect(fp.get("walking")).toBeCloseTo(1.0, 5);
  });

  it("applies a 1.5× weight to unclassified tags", () => {
    const photos = [
      makePhoto(USER_A, { tags: ["zorbing"], adventureScore: 0 }),
    ];
    const fp = buildFingerprint(photos, null);
    expect(fp.get("zorbing")).toBeCloseTo(1.5, 5);
  });

  it("scales photo tag weight by adventureScore", () => {
    const lowScore  = makePhoto(USER_A, { tags: ["hiking"], adventureScore: 0 });
    const highScore = makePhoto(USER_A, { tags: ["hiking"], adventureScore: 200 });

    const fpLow  = buildFingerprint([lowScore], null);
    const fpHigh = buildFingerprint([highScore], null);

    // high = 1.0 × (1 + 200/200) = 2.0; low = 1.0 × (1 + 0/200) = 1.0
    expect(fpHigh.get("hiking")!).toBeGreaterThan(fpLow.get("hiking")!);
    expect(fpHigh.get("hiking")).toBeCloseTo(2.0, 5);
  });

  it("adventure tags take priority over lower photo weights for the same tag", () => {
    // Photo tag gives weight 1.0, adventure tag gives 1.0 × 1.4 = 1.4
    // buildFingerprint uses Math.max for the manual tag
    const photo = makePhoto(USER_A, { tags: ["hiking"], adventureScore: 0 });
    const fp = buildFingerprint([photo], ["hiking"]);
    expect(fp.get("hiking")).toBeCloseTo(1.4, 5);
  });

  it("adventure tags do not reduce an already-higher photo weight", () => {
    // Photo with high adventureScore gives 1.0 × (1 + 200/200) = 2.0
    // Adventure tag gives 1.0 × 1.4 = 1.4 — should NOT override the 2.0
    const photo = makePhoto(USER_A, { tags: ["hiking"], adventureScore: 200 });
    const fp = buildFingerprint([photo], ["hiking"]);
    expect(fp.get("hiking")).toBeCloseTo(2.0, 5);
  });

  it("normalises tag casing — 'Hiking' and 'hiking' are the same tag", () => {
    const photo = makePhoto(USER_A, { tags: ["Hiking", "SURFING"] });
    const fp = buildFingerprint([photo], ["Hiking"]);
    expect(fp.has("hiking")).toBe(true);
    expect(fp.has("surfing")).toBe(true);
    expect(fp.has("Hiking")).toBe(false);
    expect(fp.has("SURFING")).toBe(false);
  });

  it("trims whitespace from tags", () => {
    const photo = makePhoto(USER_A, { tags: ["  hiking  ", " surfing"] });
    const fp = buildFingerprint([photo], null);
    expect(fp.has("hiking")).toBe(true);
    expect(fp.has("surfing")).toBe(true);
  });
});

// ---------------------------------------------------------------------------
// computeOverlap
// ---------------------------------------------------------------------------

describe("computeOverlap", () => {
  it("returns score 0 and empty tags when either fingerprint is empty", () => {
    const fp = buildFingerprint([makePhoto(USER_A, { tags: ["hiking"] })], null);
    const empty = new Map<string, number>();

    expect(computeOverlap(fp, empty)).toEqual({ score: 0, sharedTags: [] });
    expect(computeOverlap(empty, fp)).toEqual({ score: 0, sharedTags: [] });
    expect(computeOverlap(empty, empty)).toEqual({ score: 0, sharedTags: [] });
  });

  it("returns score 1.0 when both fingerprints are identical", () => {
    const photos = [makePhoto(USER_A, { tags: ["hiking", "surfing"], adventureScore: 50 })];
    const fp = buildFingerprint(photos, null);
    // Identical fingerprints should score 1.0 (perfect overlap)
    const { score } = computeOverlap(fp, fp);
    expect(score).toBe(1.0);
  });

  it("returns score 0 when users share no tags at all", () => {
    const fpA = buildFingerprint([makePhoto(USER_A, { tags: ["skydiving"] })], null);
    const fpB = buildFingerprint([makePhoto(USER_B, { tags: ["yoga / wellness"] })], null);
    const { score, sharedTags } = computeOverlap(fpA, fpB);
    expect(score).toBe(0);
    expect(sharedTags).toHaveLength(0);
  });

  it("is symmetric — overlap(A,B) equals overlap(B,A)", () => {
    const fpA = buildFingerprint(
      [makePhoto(USER_A, { tags: ["hiking", "surfing", "skydiving"] })],
      ["kayaking"],
    );
    const fpB = buildFingerprint(
      [makePhoto(USER_B, { tags: ["surfing", "kayaking", "photography"] })],
      null,
    );
    const { score: ab } = computeOverlap(fpA, fpB);
    const { score: ba } = computeOverlap(fpB, fpA);
    expect(ab).toBe(ba);
  });

  it("score is bounded between 0 and 1 inclusive", () => {
    const scenarios = [
      [["hiking"], ["hiking"]],
      [["skydiving", "surfing"], ["hiking", "surfing"]],
      [["hiking"], ["skydiving", "surfing", "kayaking"]],
    ] as const;

    for (const [tagsA, tagsB] of scenarios) {
      const fpA = buildFingerprint([makePhoto(USER_A, { tags: [...tagsA] })], null);
      const fpB = buildFingerprint([makePhoto(USER_B, { tags: [...tagsB] })], null);
      const { score } = computeOverlap(fpA, fpB);
      expect(score).toBeGreaterThanOrEqual(0);
      expect(score).toBeLessThanOrEqual(1);
    }
  });

  it("lists all shared tags in the result", () => {
    const fpA = buildFingerprint(
      [makePhoto(USER_A, { tags: ["hiking", "surfing", "skydiving"] })],
      null,
    );
    const fpB = buildFingerprint(
      [makePhoto(USER_B, { tags: ["surfing", "skydiving", "yoga / wellness"] })],
      null,
    );
    const { sharedTags } = computeOverlap(fpA, fpB);
    expect(sharedTags).toContain("surfing");
    expect(sharedTags).toContain("skydiving");
    expect(sharedTags).not.toContain("hiking");
    expect(sharedTags).not.toContain("yoga / wellness");
    expect(sharedTags).toHaveLength(2);
  });

  it("a rare tag in common lifts score more than a common tag in common", () => {
    // fpA has skydiving (rare=4) and surfing (common=1)
    const fpA = buildFingerprint(
      [makePhoto(USER_A, { tags: ["skydiving"], adventureScore: 0 })],
      null,
    );
    // fpB_rare shares the rare tag; fpB_common shares only the common tag
    const fpB_rare = buildFingerprint(
      [makePhoto(USER_B, { tags: ["skydiving"], adventureScore: 0 })],
      null,
    );
    const fpB_common = buildFingerprint(
      [makePhoto(USER_B, { tags: ["surfing"], adventureScore: 0 })],
      null,
    );
    const fpA_with_common = buildFingerprint(
      [makePhoto(USER_A, { tags: ["skydiving", "surfing"], adventureScore: 0 })],
      null,
    );

    const { score: rareScore }   = computeOverlap(fpA_with_common, fpB_rare);
    const { score: commonScore } = computeOverlap(fpA_with_common, fpB_common);

    // Sharing the rare tag should produce a higher score
    expect(rareScore).toBeGreaterThan(commonScore);
  });

  it("rounds score to 2 decimal places", () => {
    const fpA = buildFingerprint([makePhoto(USER_A, { tags: ["hiking", "surfing"] })], null);
    const fpB = buildFingerprint([makePhoto(USER_B, { tags: ["hiking"] })], null);
    const { score } = computeOverlap(fpA, fpB);
    const rounded = Math.round(score * 100) / 100;
    expect(score).toBe(rounded);
  });
});

// ---------------------------------------------------------------------------
// detectAlmostMet
// ---------------------------------------------------------------------------

describe("detectAlmostMet", () => {
  it("returns null when neither user has any photos", () => {
    expect(detectAlmostMet([], [])).toBeNull();
  });

  it("returns null when users have photos but no location overlap", () => {
    const photosA = [makePhoto(USER_A, { caption: "Great day in Queenstown" })];
    const photosB = [makePhoto(USER_B, { caption: "Loved Tokyo" })];
    expect(detectAlmostMet(photosA, photosB)).toBeNull();
  });

  it("detects a shared destination from captions", () => {
    const photosA = [makePhotoWithLocation(USER_A, "Queenstown")];
    const photosB = [makePhotoWithLocation(USER_B, "queenstown")]; // case-insensitive

    const result = detectAlmostMet(photosA, photosB);
    expect(result).not.toBeNull();
    expect(result!.location).toBe("Queenstown");
  });

  it("detects a shared destination from photo tags (not just captions)", () => {
    const photosA = [makePhoto(USER_A, { tags: ["bali", "surfing"], caption: null })];
    const photosB = [makePhoto(USER_B, { tags: ["bali", "hiking"], caption: null })];
    const result = detectAlmostMet(photosA, photosB);
    expect(result).not.toBeNull();
    expect(result!.location).toBe("Bali");
  });

  it("includes the year in dateHint when photos are within 1 year of each other", () => {
    const photosA = [makePhotoWithLocation(USER_A, "Iceland", new Date("2024-07-15"))];
    const photosB = [makePhotoWithLocation(USER_B, "Iceland", new Date("2025-02-10"))];
    const result = detectAlmostMet(photosA, photosB);
    expect(result).not.toBeNull();
    // Same-year check: |2024 - 2025| = 1 ≤ 1 → same year branch
    expect(result!.dateHint).toBe("2024");
  });

  it("uses 'different times' in dateHint when photos are more than 1 year apart", () => {
    const photosA = [makePhotoWithLocation(USER_A, "Iceland", new Date("2022-01-01"))];
    const photosB = [makePhotoWithLocation(USER_B, "Iceland", new Date("2025-06-01"))];
    const result = detectAlmostMet(photosA, photosB);
    expect(result).not.toBeNull();
    expect(result!.dateHint).toContain("different times");
  });

  it("is not symmetric about who is A and who is B", () => {
    // Implementation scans photosB looking into locationsA — both orders should find the match
    const photosA = [makePhotoWithLocation(USER_A, "Milford")];
    const photosB = [makePhotoWithLocation(USER_B, "Milford")];
    const ab = detectAlmostMet(photosA, photosB);
    const ba = detectAlmostMet(photosB, photosA);
    // Both should find it (or both null — symmetry is acceptable either way)
    expect(ab === null).toBe(ba === null);
  });

  it("only matches known locations — generic words are not detected", () => {
    const photosA = [makePhoto(USER_A, { caption: "Beautiful beach trip" })];
    const photosB = [makePhoto(USER_B, { caption: "Another beach trip" })];
    expect(detectAlmostMet(photosA, photosB)).toBeNull();
  });
});

// ---------------------------------------------------------------------------
// computeHonestyTier
// ---------------------------------------------------------------------------

describe("computeHonestyTier", () => {
  it("returns 'unverified' when user has no photos", () => {
    expect(computeHonestyTier([])).toBe("unverified");
  });

  it("returns 'verified-adventure' when ≥80% approved and avg authenticity ≥75", () => {
    const photos = [
      makePhoto(USER_A, { verdict: "approved", authenticityScore: 90 }),
      makePhoto(USER_A, { verdict: "approved", authenticityScore: 80 }),
      makePhoto(USER_A, { verdict: "approved", authenticityScore: 85 }),
      makePhoto(USER_A, { verdict: "approved", authenticityScore: 90 }),
      makePhoto(USER_A, { verdict: "rejected_stock", authenticityScore: 60 }),
    ];
    // 4/5 = 80% approved ✓, avg auth = (90+80+85+90+60)/5 = 81 ✓
    expect(computeHonestyTier(photos)).toBe("verified-adventure");
  });

  it("returns 'unverified' when approval ratio is below 50% and avg authenticity is low", () => {
    const photos = [
      makePhoto(USER_A, { verdict: "rejected_stock", authenticityScore: 20 }),
      makePhoto(USER_A, { verdict: "rejected_manipulated", authenticityScore: 10 }),
      makePhoto(USER_A, { verdict: "approved", authenticityScore: 30 }),
    ];
    // 1/3 ≈ 33% approved ✗, avg auth = (20+10+30)/3 ≈ 20 ✗
    expect(computeHonestyTier(photos)).toBe("unverified");
  });

  it("returns 'mostly-verified' when exactly 50% are approved", () => {
    const photos = [
      makePhoto(USER_A, { verdict: "approved", authenticityScore: 40 }),
      makePhoto(USER_A, { verdict: "rejected_stock", authenticityScore: 40 }),
    ];
    // 1/2 = 50% ≥ 50% → mostly-verified; avg auth = 40 < 50 but ratio passes
    expect(computeHonestyTier(photos)).toBe("mostly-verified");
  });

  it("returns 'mostly-verified' when avg authenticity ≥50 even if ratio is low", () => {
    const photos = [
      makePhoto(USER_A, { verdict: "rejected_stock", authenticityScore: 90 }),
      makePhoto(USER_A, { verdict: "rejected_stock", authenticityScore: 70 }),
      makePhoto(USER_A, { verdict: "approved", authenticityScore: 60 }),
    ];
    // 1/3 ≈ 33% approved (< 50%) but avg auth = (90+70+60)/3 ≈ 73 ≥ 50 → mostly-verified
    expect(computeHonestyTier(photos)).toBe("mostly-verified");
  });

  it("requires BOTH conditions for 'verified-adventure' — high ratio alone is not enough", () => {
    const photos = [
      makePhoto(USER_A, { verdict: "approved", authenticityScore: 10 }),
      makePhoto(USER_A, { verdict: "approved", authenticityScore: 10 }),
      makePhoto(USER_A, { verdict: "approved", authenticityScore: 10 }),
      makePhoto(USER_A, { verdict: "approved", authenticityScore: 10 }),
      makePhoto(USER_A, { verdict: "approved", authenticityScore: 10 }),
    ];
    // 5/5 = 100% approved ✓, but avg auth = 10 < 75 ✗ → should NOT be verified-adventure
    expect(computeHonestyTier(photos)).not.toBe("verified-adventure");
  });

  it("requires BOTH conditions for 'verified-adventure' — high authenticity alone is not enough", () => {
    const photos = [
      makePhoto(USER_A, { verdict: "approved", authenticityScore: 95 }),
      makePhoto(USER_A, { verdict: "rejected_stock", authenticityScore: 95 }),
      makePhoto(USER_A, { verdict: "rejected_stock", authenticityScore: 95 }),
    ];
    // 1/3 ≈ 33% < 80% ✗, avg auth = 95 ✓ — should NOT be verified-adventure
    expect(computeHonestyTier(photos)).not.toBe("verified-adventure");
  });

  it("single approved photo with high authenticity gives verified-adventure", () => {
    const photos = [makePhoto(USER_A, { verdict: "approved", authenticityScore: 80 })];
    // 1/1 = 100% ✓, avg = 80 ✓
    expect(computeHonestyTier(photos)).toBe("verified-adventure");
  });

  it("verdicts other than 'approved' are treated as non-approved for ratio calculation", () => {
    const nonApprovedVerdicts = [
      "needs_person",
      "rejected_quote",
      "rejected_manipulated",
      "rejected_stock",
    ] as const;

    for (const verdict of nonApprovedVerdicts) {
      const photos = [
        makePhoto(USER_A, { verdict, authenticityScore: 0 }),
        makePhoto(USER_A, { verdict, authenticityScore: 0 }),
      ];
      expect(computeHonestyTier(photos)).toBe("unverified");
    }
  });
});
