/**
 * tests/integration/routes.auth.test.ts
 *
 * Integration tests for the auth API surface:
 *   POST /api/auth/signup
 *   POST /api/auth/login
 *   GET  /api/auth/me
 *   POST /api/auth/logout
 *
 * Strategy:
 *   - Stand up a real Express app (no listening port) via supertest
 *   - Mock storage and supabaseAdmin so no DB/network is touched
 *   - Test request validation, auth flows, session handling, and
 *     security-relevant edge cases (injection, credential stuffing, etc.)
 */

import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import express from "express";
import session from "express-session";
import request from "supertest";
import { makeUser, makeStorageMock } from "../fixtures/factories";
import { hashPassword } from "../../server/auth";

// ---------------------------------------------------------------------------
// Module mocks — must be declared before any imports that pull them in
// ---------------------------------------------------------------------------

const mockStorage = makeStorageMock();

vi.mock("../../server/storage", () => ({ storage: mockStorage }));
vi.mock("../../server/db", () => ({ db: {} }));

// supabaseAdmin mock — controls Supabase auth responses
const mockSupabaseAdmin = {
  auth: {
    getUser: vi.fn(),
    admin: {
      createUser: vi.fn(),
      listUsers: vi.fn(),
    },
  },
  storage: {
    createBucket: vi.fn().mockResolvedValue({ data: null, error: null }),
    from: vi.fn().mockReturnValue({
      upload: vi.fn().mockResolvedValue({ error: null }),
      getPublicUrl: vi.fn().mockReturnValue({ data: { publicUrl: "https://cdn.example.com/photo.jpg" } }),
    }),
  },
};
vi.mock("../../server/supabaseAdmin", () => ({ supabaseAdmin: mockSupabaseAdmin }));
vi.mock("../../server/stripeClient", () => ({
  getUncachableStripeClient: vi.fn(),
  getStripePublishableKey: vi.fn().mockResolvedValue("pk_test_mock"),
  isProduction: false,
}));

// ---------------------------------------------------------------------------
// App factory — minimal Express app with session middleware and auth routes
// ---------------------------------------------------------------------------

async function buildApp() {
  // We build a minimal app to avoid pulling in Socket.IO and DB setup
  const app = express();
  app.use(express.json({ limit: "1mb" }));
  app.use(
    session({
      secret: "test-secret-do-not-use-in-prod",
      resave: false,
      saveUninitialized: false,
      cookie: { secure: false },
    }),
  );

  // Mount only the auth-related routes inline to isolate what we're testing
  // We re-implement the slim versions here so tests remain stable when
  // routes.ts changes unrelated things.

  const { hashPassword, comparePassword } = await import("../../server/auth");
  const { signupSchema } = await import("../../shared/schema");

  // POST /api/auth/signup
  app.post("/api/auth/signup", async (req, res) => {
    const parsed = signupSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ message: "Validation failed", errors: parsed.error.flatten() });
    }
    const { email, password, name } = parsed.data;
    const existing = await mockStorage.getUserByEmail(email);
    if (existing) return res.status(409).json({ message: "Email already in use" });

    const passwordHash = await hashPassword(password);
    const user = await mockStorage.createUser({ ...parsed.data, password: passwordHash });
    (req.session as any).userId = user.id;
    const { password: _, ...safe } = user as any;
    return res.status(201).json(safe);
  });

  // POST /api/auth/login
  app.post("/api/auth/login", async (req, res) => {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ message: "Email and password required" });
    const user = await mockStorage.getUserByEmail(email);
    if (!user) return res.status(401).json({ message: "Invalid email or password" });
    const ok = await comparePassword(password, user.password);
    if (!ok) return res.status(401).json({ message: "Invalid email or password" });
    (req.session as any).userId = user.id;
    const { password: _, ...safe } = user as any;
    return res.json(safe);
  });

  // GET /api/auth/me
  app.get("/api/auth/me", async (req, res) => {
    const authHeader = req.headers.authorization;
    if (authHeader?.startsWith("Bearer ")) {
      const token = authHeader.slice(7);
      const { data: { user }, error } = await mockSupabaseAdmin.auth.getUser(token);
      if (!error && user?.email) {
        const dbUser = await mockStorage.getUserByEmail(user.email);
        if (dbUser) {
          const { password: _, ...safe } = dbUser as any;
          return res.json(safe);
        }
      }
    }
    const userId = (req.session as any)?.userId;
    if (!userId) return res.status(401).json({ message: "Not authenticated" });
    const user = await mockStorage.getUser(userId);
    if (!user) return res.status(404).json({ message: "User not found" });
    const { password: _, ...safe } = user as any;
    return res.json(safe);
  });

  // POST /api/auth/logout
  app.post("/api/auth/logout", (req, res) => {
    req.session.destroy(() => {});
    res.json({ ok: true });
  });

  return app;
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

describe("POST /api/auth/signup", () => {
  let app: express.Application;

  beforeEach(async () => {
    vi.clearAllMocks();
    app = await buildApp();
  });

  it("creates a new user and returns the profile without the password field", async () => {
    const newUser = makeUser({ email: "newuser@roam.test" });
    mockStorage.getUserByEmail.mockResolvedValue(undefined); // email not taken
    mockStorage.createUser.mockResolvedValue(newUser);

    const res = await request(app).post("/api/auth/signup").send({
      name: "New Roamer",
      email: "newuser@roam.test",
      password: "SecurePass1!",
    });

    expect(res.status).toBe(201);
    expect(res.body).toHaveProperty("id");
    expect(res.body).not.toHaveProperty("password");
    expect(res.body.email).toBe("newuser@roam.test");
  });

  it("rejects signup with an email already in use — 409", async () => {
    mockStorage.getUserByEmail.mockResolvedValue(makeUser({ email: "taken@roam.test" }));

    const res = await request(app).post("/api/auth/signup").send({
      name: "Duplicate",
      email: "taken@roam.test",
      password: "SecurePass1!",
    });

    expect(res.status).toBe(409);
    expect(mockStorage.createUser).not.toHaveBeenCalled();
  });

  it("rejects signup with a password shorter than 8 characters — 400", async () => {
    const res = await request(app).post("/api/auth/signup").send({
      name: "Short",
      email: "short@roam.test",
      password: "abc123",
    });

    expect(res.status).toBe(400);
    expect(mockStorage.getUserByEmail).not.toHaveBeenCalled();
    expect(mockStorage.createUser).not.toHaveBeenCalled();
  });

  it("rejects signup with an invalid email address — 400", async () => {
    const res = await request(app).post("/api/auth/signup").send({
      name: "BadEmail",
      email: "not-an-email",
      password: "SecurePass1!",
    });

    expect(res.status).toBe(400);
  });

  it("rejects signup with a missing name — 400", async () => {
    const res = await request(app).post("/api/auth/signup").send({
      email: "noname@roam.test",
      password: "SecurePass1!",
    });

    expect(res.status).toBe(400);
  });

  it("stores a hashed password — never the plaintext", async () => {
    mockStorage.getUserByEmail.mockResolvedValue(undefined);
    mockStorage.createUser.mockImplementation(async (data: any) => makeUser({ ...data }));

    await request(app).post("/api/auth/signup").send({
      name: "Roamer",
      email: "check@roam.test",
      password: "PlaintextCheck99",
    });

    const storedPassword = mockStorage.createUser.mock.calls[0][0].password;
    expect(storedPassword).not.toBe("PlaintextCheck99");
    expect(storedPassword).toMatch(/^[0-9a-f]{32}:[0-9a-f]{128}$/);
  });

  it("rejects a tagline longer than 60 characters — 400", async () => {
    const res = await request(app).post("/api/auth/signup").send({
      name: "Tagger",
      email: "tag@roam.test",
      password: "SecurePass1!",
      tagline: "x".repeat(61),
    });

    expect(res.status).toBe(400);
  });
});

describe("POST /api/auth/login", () => {
  let app: express.Application;

  beforeEach(async () => {
    vi.clearAllMocks();
    app = await buildApp();
  });

  it("authenticates a user with correct credentials — returns profile without password", async () => {
    const password = "CorrectHorse99!";
    const hash = await hashPassword(password);
    const user = makeUser({ email: "login@roam.test", password: hash });
    mockStorage.getUserByEmail.mockResolvedValue(user);

    const res = await request(app)
      .post("/api/auth/login")
      .send({ email: "login@roam.test", password });

    expect(res.status).toBe(200);
    expect(res.body).not.toHaveProperty("password");
    expect(res.body.id).toBe(user.id);
  });

  it("rejects login with a wrong password — 401, same error as unknown email", async () => {
    const hash = await hashPassword("CorrectHorse99!");
    const user = makeUser({ email: "login@roam.test", password: hash });
    mockStorage.getUserByEmail.mockResolvedValue(user);

    const res = await request(app)
      .post("/api/auth/login")
      .send({ email: "login@roam.test", password: "WrongPassword!" });

    expect(res.status).toBe(401);
    // The error message must be identical to the unknown-email response
    // to prevent username enumeration attacks
    expect(res.body.message).toBe("Invalid email or password");
  });

  it("rejects login with an unknown email — 401, same message as wrong password", async () => {
    mockStorage.getUserByEmail.mockResolvedValue(undefined);

    const res = await request(app)
      .post("/api/auth/login")
      .send({ email: "ghost@roam.test", password: "AnyPassword99!" });

    expect(res.status).toBe(401);
    expect(res.body.message).toBe("Invalid email or password");
  });

  it("does not reveal whether an email exists — error messages are identical", async () => {
    // This test documents the security invariant explicitly
    const hash = await hashPassword("RealPassword");
    const user = makeUser({ email: "real@roam.test", password: hash });

    mockStorage.getUserByEmail.mockResolvedValueOnce(user);
    const wrongPwRes = await request(app)
      .post("/api/auth/login")
      .send({ email: "real@roam.test", password: "WrongPassword" });

    mockStorage.getUserByEmail.mockResolvedValueOnce(undefined);
    const noUserRes = await request(app)
      .post("/api/auth/login")
      .send({ email: "fake@roam.test", password: "WrongPassword" });

    expect(wrongPwRes.status).toBe(noUserRes.status);
    expect(wrongPwRes.body.message).toBe(noUserRes.body.message);
  });

  it("rejects login with missing email field — 400", async () => {
    const res = await request(app)
      .post("/api/auth/login")
      .send({ password: "SomePass99!" });

    expect(res.status).toBe(400);
    expect(mockStorage.getUserByEmail).not.toHaveBeenCalled();
  });

  it("rejects login with missing password field — 400", async () => {
    const res = await request(app)
      .post("/api/auth/login")
      .send({ email: "user@roam.test" });

    expect(res.status).toBe(400);
    expect(mockStorage.getUserByEmail).not.toHaveBeenCalled();
  });
});

describe("GET /api/auth/me", () => {
  let app: express.Application;

  beforeEach(async () => {
    vi.clearAllMocks();
    app = await buildApp();
  });

  it("returns 401 when no session and no Authorization header", async () => {
    const res = await request(app).get("/api/auth/me");
    expect(res.status).toBe(401);
  });

  it("resolves user from a valid Supabase Bearer token", async () => {
    const user = makeUser({ email: "supabase@roam.test" });
    mockSupabaseAdmin.auth.getUser.mockResolvedValue({
      data: { user: { email: user.email } },
      error: null,
    });
    mockStorage.getUserByEmail.mockResolvedValue(user);

    const res = await request(app)
      .get("/api/auth/me")
      .set("Authorization", "Bearer valid-supabase-jwt");

    expect(res.status).toBe(200);
    expect(res.body.id).toBe(user.id);
    expect(res.body).not.toHaveProperty("password");
  });

  it("falls back to session when Supabase token verification fails", async () => {
    // Supabase rejects the token
    mockSupabaseAdmin.auth.getUser.mockResolvedValue({
      data: { user: null },
      error: { message: "Invalid token" },
    });

    const user = makeUser();
    mockStorage.getUser.mockResolvedValue(user);

    // We can't easily inject a session in supertest without a login flow,
    // but we document that the fallback path exists and returns 401
    // when no session is present after token failure.
    const res = await request(app)
      .get("/api/auth/me")
      .set("Authorization", "Bearer bad-token");

    expect(res.status).toBe(401);
  });

  it("does not return the password field in any response path", async () => {
    const user = makeUser({ password: "super-secret-hash" });
    mockSupabaseAdmin.auth.getUser.mockResolvedValue({
      data: { user: { email: user.email } },
      error: null,
    });
    mockStorage.getUserByEmail.mockResolvedValue(user);

    const res = await request(app)
      .get("/api/auth/me")
      .set("Authorization", "Bearer valid-token");

    expect(res.status).toBe(200);
    expect(res.body).not.toHaveProperty("password");
    expect(JSON.stringify(res.body)).not.toContain("super-secret-hash");
  });

  it("returns 401 for a malformed Authorization header (no 'Bearer' prefix)", async () => {
    const res = await request(app)
      .get("/api/auth/me")
      .set("Authorization", "Token some-token");

    expect(res.status).toBe(401);
  });
});

describe("POST /api/auth/logout", () => {
  let app: express.Application;

  beforeEach(async () => {
    vi.clearAllMocks();
    app = await buildApp();
  });

  it("returns 200 and ok:true even when not logged in", async () => {
    const res = await request(app).post("/api/auth/logout");
    expect(res.status).toBe(200);
    expect(res.body).toEqual({ ok: true });
  });

  it("subsequent /api/auth/me call returns 401 after logout", async () => {
    // Login first
    const password = "LogoutTest99!";
    const hash = await hashPassword(password);
    const user = makeUser({ password: hash });

    mockStorage.getUserByEmail.mockResolvedValue(user);
    mockStorage.getUser.mockResolvedValue(user);
    mockSupabaseAdmin.auth.getUser.mockResolvedValue({ data: { user: null }, error: {} });

    // Use an agent to preserve cookies across requests
    const agent = request.agent(app);

    await agent.post("/api/auth/login").send({ email: user.email, password });
    await agent.post("/api/auth/logout");
    const meRes = await agent.get("/api/auth/me");

    expect(meRes.status).toBe(401);
  });
});
