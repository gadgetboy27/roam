/**
 * tests/fixtures/factories.ts
 * Centralised factory helpers — create minimal valid objects for every domain type.
 * Tests import what they need; factories keep test setup DRY and change-resilient.
 */

import type { User, Photo, Match, Message, Ad, AdminUser, Group, GroupMember } from "../../shared/schema";

let _seq = 0;
const seq = () => String(++_seq);
const uuid = () => `xxxxxxxx-xxxx-4xxx-yxxx-${seq().padStart(12, "0")}`;

// ---------------------------------------------------------------------------
// Users
// ---------------------------------------------------------------------------

export function makeUser(overrides: Partial<User> = {}): User {
  const id = uuid();
  return {
    id,
    email: `user-${id}@roam.test`,
    password: "scrypt-hash:placeholder",
    name: "Test Roamer",
    dob: "1995-06-15",
    gender: "any",
    ethnicity: null,
    location: "Auckland, NZ",
    tagline: "Love the outdoors",
    tier: "free",
    photoLicenseAgreed: true,
    adventureTags: ["hiking", "surfing"],
    avatarUrl: null,
    identityVerified: false,
    identityVerificationId: null,
    identityVerifiedAt: null,
    stripeCustomerId: null,
    stripeSubscriptionId: null,
    openToRoaming: false,
    isFoundingMember: false,
    isTierGifted: false,
    boostExpiresAt: null,
    isOrganiser: false,
    stripeConnectAccountId: null,
    stripeConnectOnboarded: false,
    createdAt: new Date("2025-01-01T00:00:00Z"),
    ...overrides,
  };
}

export function makeAdminUser(overrides: Partial<AdminUser> = {}): AdminUser {
  const id = uuid();
  return {
    id,
    username: `admin-${id}`,
    passwordHash: "scrypt-hash:placeholder",
    displayName: "Test Admin",
    createdAt: new Date("2025-01-01T00:00:00Z"),
    createdBy: null,
    ...overrides,
  };
}

// ---------------------------------------------------------------------------
// Photos
// ---------------------------------------------------------------------------

export function makePhoto(userId: string, overrides: Partial<Photo> = {}): Photo {
  return {
    id: uuid(),
    userId,
    storageUrl: `https://cdn.supabase.co/photos/${userId}/test.jpg`,
    caption: null,
    personScore: 80,
    authenticityScore: 90,
    adventureScore: 70,
    verdict: "approved",
    tags: ["hiking"],
    manipulationFlags: [],
    isLicensable: false,
    displayOrder: 0,
    createdAt: new Date("2025-06-01T00:00:00Z"),
    ...overrides,
  };
}

export function makePhotoWithLocation(
  userId: string,
  location: string,
  createdAt: Date = new Date("2025-06-01T00:00:00Z"),
): Photo {
  return makePhoto(userId, {
    caption: `Amazing trip to ${location}`,
    tags: [location.toLowerCase(), "hiking"],
    createdAt,
  });
}

// ---------------------------------------------------------------------------
// Matches
// ---------------------------------------------------------------------------

export function makeMatch(userAId: string, userBId: string, overrides: Partial<Match> = {}): Match {
  return {
    id: uuid(),
    userAId,
    userBId,
    overlapScore: 0.65,
    sharedTags: ["hiking", "surfing"],
    status: "matched",
    almostMetLocation: null,
    almostMetDate: null,
    createdAt: new Date("2025-03-01T00:00:00Z"),
    matchedAt: new Date("2025-03-02T00:00:00Z"),
    ...overrides,
  };
}

export function makePendingMatch(userAId: string, userBId: string): Match {
  return makeMatch(userAId, userBId, { status: "pending", matchedAt: null });
}

// ---------------------------------------------------------------------------
// Messages
// ---------------------------------------------------------------------------

export function makeMessage(matchId: string, senderId: string, overrides: Partial<Message> = {}): Message {
  return {
    id: uuid(),
    matchId,
    senderId,
    content: "Hey, saw you at Tongariro last month!",
    createdAt: new Date("2025-03-03T10:00:00Z"),
    ...overrides,
  };
}

// ---------------------------------------------------------------------------
// Ads
// ---------------------------------------------------------------------------

export function makeAd(overrides: Partial<Ad> = {}): Ad {
  return {
    id: uuid(),
    advertiserName: "Outdoor Gear NZ",
    advertiserEmail: "ads@outdoorgear.co.nz",
    advertiserCompany: "Outdoor Gear NZ Ltd",
    tier: "standard",
    headline: "50% Off Trail Gear",
    tagline: "For real adventurers",
    ctaText: "Shop Now",
    ctaUrl: "https://outdoorgear.co.nz",
    imageUrl: "https://cdn.example.com/ad.jpg",
    videoUrl: null,
    contentType: "image",
    status: "approved",
    stripeSessionId: null,
    rejectionReason: null,
    reviewedAt: null,
    expiresAt: new Date(Date.now() + 7 * 86_400_000),
    impressions: 0,
    clicks: 0,
    adType: "standard",
    submittedByUserId: null,
    linkedGroupId: null,
    linkedEventId: null,
    eventStartAt: null,
    eventLocation: null,
    createdAt: new Date("2025-01-15T00:00:00Z"),
    ...overrides,
  };
}

// ---------------------------------------------------------------------------
// Storage mock builder
// ---------------------------------------------------------------------------

/**
 * Returns a minimal IStorage mock with every method stubbed to throw.
 * Individual tests override only the methods they need — enforces that
 * routes don't accidentally call storage methods they shouldn't.
 */
export function makeStorageMock() {
  const notImplemented = (name: string) => () => {
    throw new Error(`storage.${name} called unexpectedly — did you mean to stub it?`);
  };

  return {
    getUser: vi.fn(notImplemented("getUser")),
    getUserByEmail: vi.fn(notImplemented("getUserByEmail")),
    createUser: vi.fn(notImplemented("createUser")),
    updateUser: vi.fn(notImplemented("updateUser")),
    getAllUsers: vi.fn(notImplemented("getAllUsers")),
    countFoundingMembers: vi.fn(notImplemented("countFoundingMembers")),
    getUserByStripeCustomerId: vi.fn(notImplemented("getUserByStripeCustomerId")),
    createPhoto: vi.fn(notImplemented("createPhoto")),
    getPhotosByUser: vi.fn(notImplemented("getPhotosByUser")),
    getFirstApprovedPhotoPerUser: vi.fn(notImplemented("getFirstApprovedPhotoPerUser")),
    createMatch: vi.fn(notImplemented("createMatch")),
    getMatchById: vi.fn(notImplemented("getMatchById")),
    getMatchesForUser: vi.fn(notImplemented("getMatchesForUser")),
    getMatchBetween: vi.fn(notImplemented("getMatchBetween")),
    updateMatchStatus: vi.fn(notImplemented("updateMatchStatus")),
    getMonthlyConnectionsSent: vi.fn(notImplemented("getMonthlyConnectionsSent")),
    getInteractedUserIds: vi.fn(notImplemented("getInteractedUserIds")),
    createPass: vi.fn(notImplemented("createPass")),
    createMessage: vi.fn(notImplemented("createMessage")),
    getMessagesByMatch: vi.fn(notImplemented("getMessagesByMatch")),
    createBucketItem: vi.fn(notImplemented("createBucketItem")),
    getBucketListByUser: vi.fn(notImplemented("getBucketListByUser")),
    deleteBucketItem: vi.fn(notImplemented("deleteBucketItem")),
    updateUserVerification: vi.fn(notImplemented("updateUserVerification")),
    deleteUser: vi.fn(notImplemented("deleteUser")),
    createAd: vi.fn(notImplemented("createAd")),
    getAdById: vi.fn(notImplemented("getAdById")),
    getAllAds: vi.fn(notImplemented("getAllAds")),
    getAdsByStatus: vi.fn(notImplemented("getAdsByStatus")),
    getLiveAd: vi.fn(notImplemented("getLiveAd")),
    getPublicEventAds: vi.fn(notImplemented("getPublicEventAds")),
    updateAd: vi.fn(notImplemented("updateAd")),
    createAdmin: vi.fn(notImplemented("createAdmin")),
    getAdminByUsername: vi.fn(notImplemented("getAdminByUsername")),
    getAdminById: vi.fn(notImplemented("getAdminById")),
    getAllAdmins: vi.fn(notImplemented("getAllAdmins")),
    getAdminCount: vi.fn(notImplemented("getAdminCount")),
    deleteAdmin: vi.fn(notImplemented("deleteAdmin")),
    createGroup: vi.fn(notImplemented("createGroup")),
    getGroup: vi.fn(notImplemented("getGroup")),
    getAllGroups: vi.fn(notImplemented("getAllGroups")),
    updateGroup: vi.fn(notImplemented("updateGroup")),
    deleteGroup: vi.fn(notImplemented("deleteGroup")),
    addGroupMember: vi.fn(notImplemented("addGroupMember")),
    getGroupMember: vi.fn(notImplemented("getGroupMember")),
    getGroupMembers: vi.fn(notImplemented("getGroupMembers")),
    updateGroupMember: vi.fn(notImplemented("updateGroupMember")),
    removeGroupMember: vi.fn(notImplemented("removeGroupMember")),
    getGroupsForUser: vi.fn(notImplemented("getGroupsForUser")),
    getUserActiveGroupIds: vi.fn(notImplemented("getUserActiveGroupIds")),
    createGroupMessage: vi.fn(notImplemented("createGroupMessage")),
    getGroupMessages: vi.fn(notImplemented("getGroupMessages")),
    createGroupEvent: vi.fn(notImplemented("createGroupEvent")),
    getGroupEvents: vi.fn(notImplemented("getGroupEvents")),
    getGroupEvent: vi.fn(notImplemented("getGroupEvent")),
    getEventAttendee: vi.fn(notImplemented("getEventAttendee")),
    markTicketPaid: vi.fn(notImplemented("markTicketPaid")),
    rsvpEventTicketed: vi.fn(notImplemented("rsvpEventTicketed")),
    createGroupInvite: vi.fn(notImplemented("createGroupInvite")),
    getGroupInviteByToken: vi.fn(notImplemented("getGroupInviteByToken")),
    getGroupInvites: vi.fn(notImplemented("getGroupInvites")),
    updateGroupInvite: vi.fn(notImplemented("updateGroupInvite")),
    createNotification: vi.fn(notImplemented("createNotification")),
    getNotifications: vi.fn(notImplemented("getNotifications")),
    markNotificationsRead: vi.fn(notImplemented("markNotificationsRead")),
    getUnreadNotificationCount: vi.fn(notImplemented("getUnreadNotificationCount")),
  };
}
