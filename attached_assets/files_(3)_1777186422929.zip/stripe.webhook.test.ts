/**
 * tests/integration/stripe.webhook.test.ts
 *
 * Tests for the Stripe webhook endpoint:
 *   POST /api/stripe/payment-webhook
 *   POST /api/stripe/identity-webhook
 *
 * Key invariants:
 *   1. Requests with no signature header are rejected (in production)
 *   2. Requests with a bad signature are rejected with 400
 *   3. Valid events trigger the correct storage updates
 *   4. Unknown event types are ignored without error
 *   5. metadata.type determines which storage path is taken
 *   6. Webhook endpoint does NOT require user authentication (Stripe calls it)
 */

import { describe, it, expect, vi, beforeEach } from "vitest";
import express from "express";
import request from "supertest";
import { makeUser, makeStorageMock } from "../fixtures/factories";

// ---------------------------------------------------------------------------
// Mocks
// ---------------------------------------------------------------------------

const mockStorage = makeStorageMock();
vi.mock("../../server/storage", () => ({ storage: mockStorage }));
vi.mock("../../server/db", () => ({ db: {} }));
vi.mock("../../server/supabaseAdmin", () => ({
  supabaseAdmin: {
    auth: { getUser: vi.fn(), admin: { createUser: vi.fn() } },
    storage: { createBucket: vi.fn().mockResolvedValue({}) },
  },
}));

// Mock stripe — we control what constructEvent returns
const mockConstructEvent = vi.fn();
const mockStripe = {
  webhooks: { constructEvent: mockConstructEvent },
};
vi.mock("../../server/stripeClient", () => ({
  getUncachableStripeClient: vi.fn().mockResolvedValue(mockStripe),
  isProduction: false,
}));

// ---------------------------------------------------------------------------
// App factory — minimal Express with rawBody support and webhook routes
// ---------------------------------------------------------------------------

function buildWebhookApp({
  paymentWebhookSecret,
  identityWebhookSecret,
  isProduction = false,
}: {
  paymentWebhookSecret?: string;
  identityWebhookSecret?: string;
  isProduction?: boolean;
}) {
  const app = express();

  // Replicate rawBody capture from server/index.ts
  app.use(
    express.json({
      verify: (req: any, _res, buf) => { req.rawBody = buf; },
    }),
  );

  // POST /api/stripe/payment-webhook
  app.post("/api/stripe/payment-webhook", async (req, res) => {
    const sig = req.headers["stripe-signature"] as string;
    const webhookSecret = paymentWebhookSecret;
    let event: any;

    try {
      const stripe = await (await import("../../server/stripeClient")).getUncachableStripeClient();
      if (webhookSecret && sig) {
        event = stripe.webhooks.constructEvent((req as any).rawBody, sig, webhookSecret);
      } else {
        if (isProduction) {
          return res.status(400).json({ error: "Webhook signature verification required in production" });
        }
        event = req.body;
      }
    } catch (err: any) {
      return res.status(400).json({ error: `Webhook Error: ${err.message}` });
    }

    if (event?.type === "checkout.session.completed") {
      const session = event.data?.object;
      const metaType = session?.metadata?.type;

      if (metaType === "ad") {
        const adId = session?.metadata?.adId;
        if (adId) await mockStorage.updateAd(adId, { status: "pending_review" });
      } else if (metaType === "boost") {
        const userId = session?.metadata?.userId;
        if (userId) {
          const boostExpiry = new Date(Date.now() + 24 * 60 * 60 * 1000);
          await mockStorage.updateUser(userId, { boostExpiresAt: boostExpiry } as any);
        }
      } else if (metaType === "organiser") {
        const userId = session?.metadata?.userId;
        if (userId) await mockStorage.updateUser(userId, { isOrganiser: true } as any);
      } else {
        const userId = session?.metadata?.userId;
        if (userId) {
          await mockStorage.updateUser(userId, {
            tier: "adventurer",
            stripeCustomerId: session.customer,
            stripeSubscriptionId: session.subscription,
          });
        }
      }
    }

    if (event?.type === "customer.subscription.deleted") {
      const sub = event.data?.object;
      const customerId = sub?.customer;
      if (customerId) {
        const user = await mockStorage.getUserByStripeCustomerId(customerId);
        if (user) await mockStorage.updateUser(user.id, { tier: "free" } as any);
      }
    }

    return res.json({ received: true });
  });

  // POST /api/stripe/identity-webhook
  app.post("/api/stripe/identity-webhook", async (req, res) => {
    const sig = req.headers["stripe-signature"] as string;
    const webhookSecret = identityWebhookSecret;
    let event: any;

    try {
      const stripe = await (await import("../../server/stripeClient")).getUncachableStripeClient();
      if (webhookSecret && sig) {
        event = stripe.webhooks.constructEvent((req as any).rawBody, sig, webhookSecret);
      } else {
        if (isProduction) {
          return res.status(400).json({ error: "Webhook signature verification required in production" });
        }
        event = req.body;
      }
    } catch (err: any) {
      return res.status(400).json({ error: `Webhook Error: ${err.message}` });
    }

    if (event?.type === "identity.verification_session.verified") {
      const session = event.data?.object;
      const userId = session?.metadata?.userId;
      if (userId) await mockStorage.updateUserVerification(userId, session.id, true);
    }

    return res.json({ received: true });
  });

  return app;
}

// ---------------------------------------------------------------------------
// POST /api/stripe/payment-webhook — signature verification
// ---------------------------------------------------------------------------

describe("POST /api/stripe/payment-webhook — signature verification", () => {
  beforeEach(() => vi.clearAllMocks());

  it("rejects requests with an invalid Stripe signature — 400", async () => {
    mockConstructEvent.mockImplementationOnce(() => {
      throw new Error("No signatures found matching the expected signature for payload");
    });

    const app = buildWebhookApp({ paymentWebhookSecret: "whsec_test_secret" });
    const res = await request(app)
      .post("/api/stripe/payment-webhook")
      .set("stripe-signature", "t=12345,v1=badhash")
      .send(JSON.stringify({ type: "checkout.session.completed" }));

    expect(res.status).toBe(400);
    expect(res.body.error).toContain("Webhook Error");
    expect(mockStorage.updateUser).not.toHaveBeenCalled();
  });

  it("🔴 rejects requests with no signature in PRODUCTION mode", async () => {
    const app = buildWebhookApp({
      paymentWebhookSecret: "whsec_test_secret",
      isProduction: true,
    });

    const res = await request(app)
      .post("/api/stripe/payment-webhook")
      // No stripe-signature header
      .send(JSON.stringify({ type: "checkout.session.completed" }));

    expect(res.status).toBe(400);
    expect(res.body.error).toContain("required in production");
    expect(mockStorage.updateUser).not.toHaveBeenCalled();
  });

  it("accepts valid events when signature verification passes", async () => {
    const userId = "user-stripe-test";
    const fakeEvent = {
      type: "checkout.session.completed",
      data: {
        object: {
          metadata: { userId, type: "subscription" },
          customer: "cus_test",
          subscription: "sub_test",
        },
      },
    };
    mockConstructEvent.mockReturnValueOnce(fakeEvent);
    mockStorage.updateUser.mockResolvedValue({});

    const app = buildWebhookApp({ paymentWebhookSecret: "whsec_test_secret" });
    const res = await request(app)
      .post("/api/stripe/payment-webhook")
      .set("stripe-signature", "t=12345,v1=validhash")
      .set("content-type", "application/json")
      .send(JSON.stringify(fakeEvent));

    expect(res.status).toBe(200);
    expect(res.body).toEqual({ received: true });
    expect(mockStorage.updateUser).toHaveBeenCalledWith(userId, {
      tier: "adventurer",
      stripeCustomerId: "cus_test",
      stripeSubscriptionId: "sub_test",
    });
  });

  it("returns 200 and does nothing for unknown event types", async () => {
    const fakeEvent = { type: "payment_intent.created", data: { object: {} } };
    mockConstructEvent.mockReturnValueOnce(fakeEvent);

    const app = buildWebhookApp({ paymentWebhookSecret: "whsec_test" });
    const res = await request(app)
      .post("/api/stripe/payment-webhook")
      .set("stripe-signature", "t=1,v1=valid")
      .send(JSON.stringify(fakeEvent));

    expect(res.status).toBe(200);
    expect(mockStorage.updateUser).not.toHaveBeenCalled();
    expect(mockStorage.updateAd).not.toHaveBeenCalled();
  });
});

// ---------------------------------------------------------------------------
// checkout.session.completed — metadata routing
// ---------------------------------------------------------------------------

describe("POST /api/stripe/payment-webhook — metadata routing", () => {
  const userId = "user-meta-test";

  beforeEach(() => vi.clearAllMocks());

  function makeCheckoutEvent(
    metaType: string,
    extra: Record<string, any> = {},
  ) {
    return {
      type: "checkout.session.completed",
      data: {
        object: {
          id: "cs_test_session",
          customer: "cus_test",
          subscription: "sub_test",
          metadata: { type: metaType, userId, ...extra },
        },
      },
    };
  }

  it("routes 'ad' type to updateAd — sets status to pending_review", async () => {
    const adId = "ad-uuid-test";
    const event = makeCheckoutEvent("ad", { adId });
    mockConstructEvent.mockReturnValueOnce(event);
    mockStorage.updateAd.mockResolvedValue({});

    const app = buildWebhookApp({ paymentWebhookSecret: "whsec" });
    await request(app)
      .post("/api/stripe/payment-webhook")
      .set("stripe-signature", "t=1,v1=ok")
      .send(JSON.stringify(event));

    expect(mockStorage.updateAd).toHaveBeenCalledWith(adId, { status: "pending_review" });
    expect(mockStorage.updateUser).not.toHaveBeenCalled();
  });

  it("routes 'boost' type to updateUser — sets boostExpiresAt ~24h from now", async () => {
    const event = makeCheckoutEvent("boost");
    mockConstructEvent.mockReturnValueOnce(event);
    mockStorage.updateUser.mockResolvedValue({});

    const before = Date.now();
    const app = buildWebhookApp({ paymentWebhookSecret: "whsec" });
    await request(app)
      .post("/api/stripe/payment-webhook")
      .set("stripe-signature", "t=1,v1=ok")
      .send(JSON.stringify(event));
    const after = Date.now();

    expect(mockStorage.updateUser).toHaveBeenCalledOnce();
    const { boostExpiresAt } = mockStorage.updateUser.mock.calls[0][1] as any;
    const expiresMs = boostExpiresAt.getTime();
    expect(expiresMs).toBeGreaterThan(before + 23 * 3600 * 1000);
    expect(expiresMs).toBeLessThan(after + 25 * 3600 * 1000);
  });

  it("routes 'organiser' type to updateUser — sets isOrganiser: true", async () => {
    const event = makeCheckoutEvent("organiser");
    mockConstructEvent.mockReturnValueOnce(event);
    mockStorage.updateUser.mockResolvedValue({});

    const app = buildWebhookApp({ paymentWebhookSecret: "whsec" });
    await request(app)
      .post("/api/stripe/payment-webhook")
      .set("stripe-signature", "t=1,v1=ok")
      .send(JSON.stringify(event));

    expect(mockStorage.updateUser).toHaveBeenCalledWith(userId, { isOrganiser: true });
  });

  it("routes subscription checkout (no type) to tier upgrade — sets tier:'adventurer'", async () => {
    const event = {
      type: "checkout.session.completed",
      data: {
        object: {
          customer: "cus_xyz",
          subscription: "sub_xyz",
          metadata: { userId },
          // No metadata.type — falls through to subscription branch
        },
      },
    };
    mockConstructEvent.mockReturnValueOnce(event);
    mockStorage.updateUser.mockResolvedValue({});

    const app = buildWebhookApp({ paymentWebhookSecret: "whsec" });
    await request(app)
      .post("/api/stripe/payment-webhook")
      .set("stripe-signature", "t=1,v1=ok")
      .send(JSON.stringify(event));

    expect(mockStorage.updateUser).toHaveBeenCalledWith(userId, {
      tier: "adventurer",
      stripeCustomerId: "cus_xyz",
      stripeSubscriptionId: "sub_xyz",
    });
  });

  it("downgrades user to 'free' on subscription cancellation", async () => {
    const user = makeUser({ stripeCustomerId: "cus_cancelled" });
    const event = {
      type: "customer.subscription.deleted",
      data: { object: { customer: "cus_cancelled" } },
    };
    mockConstructEvent.mockReturnValueOnce(event);
    mockStorage.getUserByStripeCustomerId.mockResolvedValue(user);
    mockStorage.updateUser.mockResolvedValue({});

    const app = buildWebhookApp({ paymentWebhookSecret: "whsec" });
    await request(app)
      .post("/api/stripe/payment-webhook")
      .set("stripe-signature", "t=1,v1=ok")
      .send(JSON.stringify(event));

    expect(mockStorage.getUserByStripeCustomerId).toHaveBeenCalledWith("cus_cancelled");
    expect(mockStorage.updateUser).toHaveBeenCalledWith(user.id, { tier: "free" });
  });

  it("does nothing when subscription cancelled for unknown customer", async () => {
    const event = {
      type: "customer.subscription.deleted",
      data: { object: { customer: "cus_unknown" } },
    };
    mockConstructEvent.mockReturnValueOnce(event);
    mockStorage.getUserByStripeCustomerId.mockResolvedValue(undefined);

    const app = buildWebhookApp({ paymentWebhookSecret: "whsec" });
    const res = await request(app)
      .post("/api/stripe/payment-webhook")
      .set("stripe-signature", "t=1,v1=ok")
      .send(JSON.stringify(event));

    expect(res.status).toBe(200);
    expect(mockStorage.updateUser).not.toHaveBeenCalled();
  });
});

// ---------------------------------------------------------------------------
// POST /api/stripe/identity-webhook
// ---------------------------------------------------------------------------

describe("POST /api/stripe/identity-webhook", () => {
  beforeEach(() => vi.clearAllMocks());

  it("marks user as identity-verified when session.verified event received", async () => {
    const userId = "user-id-to-verify";
    const sessionId = "vs_test_123";
    const event = {
      type: "identity.verification_session.verified",
      data: { object: { id: sessionId, metadata: { userId } } },
    };
    mockConstructEvent.mockReturnValueOnce(event);
    mockStorage.updateUserVerification.mockResolvedValue({});

    const app = buildWebhookApp({ identityWebhookSecret: "whsec_identity" });
    const res = await request(app)
      .post("/api/stripe/identity-webhook")
      .set("stripe-signature", "t=1,v1=ok")
      .send(JSON.stringify(event));

    expect(res.status).toBe(200);
    expect(mockStorage.updateUserVerification).toHaveBeenCalledWith(userId, sessionId, true);
  });

  it("🔴 rejects unsigned identity webhooks in production", async () => {
    const app = buildWebhookApp({ identityWebhookSecret: "whsec_identity", isProduction: true });
    const res = await request(app)
      .post("/api/stripe/identity-webhook")
      // No stripe-signature
      .send(JSON.stringify({ type: "identity.verification_session.verified" }));

    expect(res.status).toBe(400);
    expect(mockStorage.updateUserVerification).not.toHaveBeenCalled();
  });

  it("does not call updateUserVerification when userId is missing from metadata", async () => {
    const event = {
      type: "identity.verification_session.verified",
      data: { object: { id: "vs_test", metadata: {} } }, // No userId
    };
    mockConstructEvent.mockReturnValueOnce(event);

    const app = buildWebhookApp({ identityWebhookSecret: "whsec_identity" });
    await request(app)
      .post("/api/stripe/identity-webhook")
      .set("stripe-signature", "t=1,v1=ok")
      .send(JSON.stringify(event));

    expect(mockStorage.updateUserVerification).not.toHaveBeenCalled();
  });
});
