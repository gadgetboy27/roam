/**
 * tests/integration/routes.upload.test.ts
 *
 * Tests for POST /api/upload — photo upload security.
 *
 * Key invariants:
 *   1. Auth required — unauthenticated users cannot upload
 *   2. userId IDOR protection — user cannot upload for another userId
 *   3. MIME type allowlist — only jpeg/png/webp/gif accepted
 *   4. File size guard — base64 strings over the limit are rejected
 *   5. dataUrl format must match the expected pattern
 */

import { describe, it, expect, vi, beforeEach } from "vitest";
import express from "express";
import session from "express-session";
import request from "supertest";
import { makeUser, makePhoto, makeStorageMock } from "../fixtures/factories";

// ---------------------------------------------------------------------------
// Mocks
// ---------------------------------------------------------------------------

const mockStorage = makeStorageMock();
vi.mock("../../server/storage", () => ({ storage: mockStorage }));
vi.mock("../../server/db", () => ({ db: {} }));

const mockSupabaseStorage = {
  upload: vi.fn().mockResolvedValue({ error: null }),
  getPublicUrl: vi.fn().mockReturnValue({
    data: { publicUrl: "https://cdn.supabase.co/photos/test.jpg" },
  }),
};
const mockSupabaseAdmin = {
  auth: { getUser: vi.fn() },
  storage: {
    createBucket: vi.fn().mockResolvedValue({}),
    from: vi.fn().mockReturnValue(mockSupabaseStorage),
  },
};
vi.mock("../../server/supabaseAdmin", () => ({ supabaseAdmin: mockSupabaseAdmin }));
vi.mock("../../server/stripeClient", () => ({
  getUncachableStripeClient: vi.fn(),
  isProduction: false,
}));

// ---------------------------------------------------------------------------
// Minimal 1×1 pixel images for testing (smallest valid base64 per format)
// ---------------------------------------------------------------------------

// 1×1 transparent PNG (67 bytes)
const VALID_PNG_B64 =
  "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==";
const VALID_PNG_DATA_URL = `data:image/png;base64,${VALID_PNG_B64}`;

// 1×1 white JPEG (631 bytes)
const VALID_JPEG_B64 =
  "/9j/4AAQSkZJRgABAQEASABIAAD/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRofHh0aHBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL/wAALCAABAAEBAREA/8QAFAABAAAAAAAAAAAAAAAAAAAACf/EABQQAQAAAAAAAAAAAAAAAAAAAAD/2gAIAQEAAD8AVIP/2Q==";
const VALID_JPEG_DATA_URL = `data:image/jpeg;base64,${VALID_JPEG_B64}`;

// ---------------------------------------------------------------------------
// App factory
// ---------------------------------------------------------------------------

function buildApp(sessionUserId: string | null = null) {
  const app = express();
  app.use(express.json({ limit: "25mb" }));
  app.use(
    session({
      secret: "test-secret",
      resave: false,
      saveUninitialized: false,
      cookie: { secure: false },
    }),
  );

  if (sessionUserId) {
    app.use((req, _res, next) => {
      (req.session as any).userId = sessionUserId;
      next();
    });
  }

  const authenticate = async (req: express.Request): Promise<string | null> => {
    const header = req.headers.authorization;
    if (header?.startsWith("Bearer ")) {
      const token = header.slice(7);
      const { data: { user }, error } = await mockSupabaseAdmin.auth.getUser(token);
      if (!error && user?.email) {
        const dbUser = await mockStorage.getUserByEmail(user.email);
        if (dbUser) return dbUser.id;
      }
    }
    return (req.session as any)?.userId || null;
  };

  const MAX_SIZE = 8 * 1024 * 1024; // 8 MB

  app.post("/api/upload", async (req, res) => {
    try {
      const authUserId = await authenticate(req);
      if (!authUserId) return res.status(401).json({ message: "Not authenticated" });

      const { dataUrl, filename, userId } = req.body;
      if (!dataUrl || !filename || !userId) {
        return res.status(400).json({ message: "dataUrl, filename, userId required" });
      }
      if (userId !== authUserId) {
        return res.status(403).json({ message: "Cannot upload photos for another user" });
      }

      // Size guard: base64 overhead factor ~1.37
      if (dataUrl.length > MAX_SIZE * 1.37) {
        return res.status(413).json({ message: "Image too large. Please use a photo under 8 MB." });
      }

      const matches = dataUrl.match(/^data:image\/(jpeg|jpg|png|webp|gif);base64,(.+)$/);
      if (!matches) {
        return res.status(400).json({ message: "Invalid image format. Use JPEG, PNG, or WebP." });
      }

      const mimeType = `image/${matches[1]}`;
      const base64Data = matches[2];
      const storagePath = `${userId}/${Date.now()}-test.${matches[1]}`;
      const fileBuffer = Buffer.from(base64Data, "base64");

      const { error: uploadError } = await mockSupabaseAdmin.storage
        .from("photos")
        .upload(storagePath, fileBuffer, { contentType: mimeType, upsert: false });

      if (uploadError) {
        return res.status(500).json({ message: `Storage error: ${uploadError.message}` });
      }

      const { data: urlData } = mockSupabaseAdmin.storage.from("photos").getPublicUrl(storagePath);
      const photo = await mockStorage.createPhoto({
        userId,
        storageUrl: urlData.publicUrl,
        caption: req.body.caption || null,
        displayOrder: req.body.displayOrder ?? 0,
        personScore: 0,
        authenticityScore: 100,
        adventureScore: 0,
        verdict: "approved",
        isLicensable: false,
      });

      return res.status(201).json(photo);
    } catch (err: any) {
      return res.status(500).json({ message: err.message });
    }
  });

  return app;
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

describe("POST /api/upload — authentication", () => {
  beforeEach(() => vi.clearAllMocks());

  it("returns 401 when no session or token present", async () => {
    const app = buildApp(null);
    const res = await request(app).post("/api/upload").send({
      dataUrl: VALID_PNG_DATA_URL,
      filename: "test.png",
      userId: "some-user-id",
    });
    expect(res.status).toBe(401);
    expect(mockStorage.createPhoto).not.toHaveBeenCalled();
    expect(mockSupabaseAdmin.storage.from).not.toHaveBeenCalled();
  });
});

describe("POST /api/upload — IDOR protection", () => {
  const attacker = makeUser();
  const victim = makeUser();

  beforeEach(() => vi.clearAllMocks());

  it("🔴 returns 403 when authenticated user tries to upload for a different userId", async () => {
    const app = buildApp(attacker.id);
    const res = await request(app).post("/api/upload").send({
      dataUrl: VALID_PNG_DATA_URL,
      filename: "test.png",
      userId: victim.id, // attacker submits victim's ID
    });
    expect(res.status).toBe(403);
    expect(res.body.message).toBe("Cannot upload photos for another user");
    expect(mockStorage.createPhoto).not.toHaveBeenCalled();
  });

  it("succeeds when userId matches the authenticated user", async () => {
    const user = makeUser();
    const photo = makePhoto(user.id);
    mockStorage.createPhoto.mockResolvedValue(photo);

    const app = buildApp(user.id);
    const res = await request(app).post("/api/upload").send({
      dataUrl: VALID_PNG_DATA_URL,
      filename: "photo.png",
      userId: user.id,
    });
    expect(res.status).toBe(201);
    expect(mockStorage.createPhoto).toHaveBeenCalledOnce();
  });
});

describe("POST /api/upload — MIME type allowlist", () => {
  const user = makeUser();

  beforeEach(() => {
    vi.clearAllMocks();
    mockStorage.createPhoto.mockResolvedValue(makePhoto(user.id));
  });

  it.each(["jpeg", "jpg", "png", "webp", "gif"])(
    "accepts valid MIME type: image/%s",
    async (ext) => {
      const app = buildApp(user.id);
      const res = await request(app).post("/api/upload").send({
        dataUrl: `data:image/${ext};base64,${VALID_PNG_B64}`,
        filename: `photo.${ext}`,
        userId: user.id,
      });
      expect(res.status).toBe(201);
    },
  );

  it("🔴 rejects SVG — could contain embedded scripts", async () => {
    const app = buildApp(user.id);
    const svgBase64 = Buffer.from('<svg><script>alert(1)</script></svg>').toString("base64");
    const res = await request(app).post("/api/upload").send({
      dataUrl: `data:image/svg+xml;base64,${svgBase64}`,
      filename: "evil.svg",
      userId: user.id,
    });
    expect(res.status).toBe(400);
    expect(mockStorage.createPhoto).not.toHaveBeenCalled();
  });

  it("🔴 rejects PDF disguised as image data", async () => {
    const app = buildApp(user.id);
    const pdfBase64 = Buffer.from("%PDF-1.4 malicious content").toString("base64");
    const res = await request(app).post("/api/upload").send({
      dataUrl: `data:application/pdf;base64,${pdfBase64}`,
      filename: "document.pdf",
      userId: user.id,
    });
    expect(res.status).toBe(400);
    expect(mockStorage.createPhoto).not.toHaveBeenCalled();
  });

  it("🔴 rejects a raw base64 string with no data: prefix (bypass attempt)", async () => {
    const app = buildApp(user.id);
    const res = await request(app).post("/api/upload").send({
      dataUrl: VALID_PNG_B64, // no data: URI prefix
      filename: "photo.png",
      userId: user.id,
    });
    expect(res.status).toBe(400);
  });

  it("🔴 rejects data URL with no MIME type (protocol manipulation)", async () => {
    const app = buildApp(user.id);
    const res = await request(app).post("/api/upload").send({
      dataUrl: `data:;base64,${VALID_PNG_B64}`,
      filename: "photo.png",
      userId: user.id,
    });
    expect(res.status).toBe(400);
  });
});

describe("POST /api/upload — file size limits", () => {
  const user = makeUser();

  beforeEach(() => vi.clearAllMocks());

  it("🔴 rejects a dataUrl that exceeds the ~8MB limit", async () => {
    const MAX_SIZE = 8 * 1024 * 1024;
    // Generate a dataUrl string longer than MAX_SIZE * 1.37
    const overSizedBase64 = "A".repeat(Math.ceil(MAX_SIZE * 1.38));
    const dataUrl = `data:image/png;base64,${overSizedBase64}`;

    const app = buildApp(user.id);
    const res = await request(app).post("/api/upload").send({
      dataUrl,
      filename: "huge.png",
      userId: user.id,
    });
    expect(res.status).toBe(413);
    expect(res.body.message).toContain("too large");
    expect(mockStorage.createPhoto).not.toHaveBeenCalled();
  });

  it("accepts a dataUrl just under the size limit", async () => {
    const MAX_SIZE = 8 * 1024 * 1024;
    // Just under the threshold — should pass the size check
    // Use a valid data URL prefix to avoid failing on MIME check
    const underSizedBase64 = VALID_PNG_B64; // well under limit
    const photo = makePhoto(user.id);
    mockStorage.createPhoto.mockResolvedValue(photo);

    const app = buildApp(user.id);
    const res = await request(app).post("/api/upload").send({
      dataUrl: VALID_PNG_DATA_URL,
      filename: "ok.png",
      userId: user.id,
    });
    expect(res.status).toBe(201);
  });
});

describe("POST /api/upload — required fields", () => {
  const user = makeUser();

  beforeEach(() => vi.clearAllMocks());

  it.each([
    [{ filename: "f.png", userId: user.id }, "missing dataUrl"],
    [{ dataUrl: VALID_PNG_DATA_URL, userId: user.id }, "missing filename"],
    [{ dataUrl: VALID_PNG_DATA_URL, filename: "f.png" }, "missing userId"],
  ])("returns 400 when field is missing — %s", async (body, _desc) => {
    const app = buildApp(user.id);
    const res = await request(app).post("/api/upload").send(body);
    expect(res.status).toBe(400);
  });
});

describe("POST /api/upload — Supabase Storage error handling", () => {
  const user = makeUser();

  beforeEach(() => vi.clearAllMocks());

  it("returns 500 when Supabase storage upload fails", async () => {
    mockSupabaseAdmin.storage.from.mockReturnValue({
      upload: vi.fn().mockResolvedValue({ error: { message: "Storage quota exceeded" } }),
      getPublicUrl: vi.fn(),
    });

    const app = buildApp(user.id);
    const res = await request(app).post("/api/upload").send({
      dataUrl: VALID_PNG_DATA_URL,
      filename: "photo.png",
      userId: user.id,
    });

    expect(res.status).toBe(500);
    expect(res.body.message).toContain("Storage error");
    expect(mockStorage.createPhoto).not.toHaveBeenCalled();
  });
});
