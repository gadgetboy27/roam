import { defineConfig } from "vitest/config";
import path from "path";

export default defineConfig({
  test: {
    globals: true,
    environment: "node",
    coverage: {
      provider: "v8",
      reporter: ["text", "html"],
      include: ["server/**", "shared/**"],
      exclude: ["server/seed.ts", "server/vite.ts", "server/static.ts"],
    },
    testTimeout: 10_000,
    hookTimeout: 10_000,
    sequence: { shuffle: false },
    reporters: ["verbose"],
  },
  resolve: {
    alias: {
      "@shared": path.resolve(__dirname, "./shared"),
      "@": path.resolve(__dirname, "./client/src"),
    },
  },
});
