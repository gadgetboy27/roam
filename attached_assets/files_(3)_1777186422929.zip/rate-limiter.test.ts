/**
 * tests/unit/rate-limiter.test.ts
 *
 * Unit tests for the custom in-memory rate limiter (server/routes.ts).
 *
 * We extract the rate limiter logic into a standalone function so it can
 * be tested in isolation — this is the "extract-to-test" pattern.
 *
 * Tests cover:
 *   1. Requests within the limit are allowed
 *   2. Requests at the limit are allowed; the next one is blocked
 *   3. Window resets after the time window expires
 *   4. Rate limiter adds Retry-After header on 429
 *   5. Different IPs are counted independently
 *   6. AUDIT C5 — in-memory reset vulnerability documented
 */

import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import type { Request, Response, NextFunction } from "express";

// ---------------------------------------------------------------------------
// Extract the rate limiter for isolated testing
// (Copy of the exact implementation from routes.ts)
// ---------------------------------------------------------------------------

function createRateLimiter(maxRequests: number, windowMs: number, message?: string) {
  const store = new Map<string, { count: number; resetAt: number }>();
  const defaultMsg = `Too many requests. Please try again in ${Math.round(windowMs / 60000)} minutes.`;

  return function rateLimiter(req: Request, res: Response, next: NextFunction) {
    const key = req.ip || "unknown";
    const now = Date.now();
    const rec = store.get(key);
    if (rec && now < rec.resetAt) {
      if (rec.count >= maxRequests) {
        res.set("Retry-After", String(Math.ceil((rec.resetAt - now) / 1000)));
        return res.status(429).json({ message: message || defaultMsg });
      }
      rec.count++;
    } else {
      store.set(key, { count: 1, resetAt: now + windowMs });
    }
    next();
  };
}

// ---------------------------------------------------------------------------
// Test helpers — fake Express req/res/next
// ---------------------------------------------------------------------------

function makeReq(ip: string = "127.0.0.1"): Request {
  return { ip } as unknown as Request;
}

function makeRes() {
  const headers: Record<string, string> = {};
  let statusCode = 200;
  let body: any;

  const res = {
    status(code: number) { statusCode = code; return res; },
    json(b: any) { body = b; return res; },
    set(key: string, val: string) { headers[key] = val; return res; },
    getStatus: () => statusCode,
    getBody: () => body,
    getHeaders: () => headers,
  } as unknown as Response & { getStatus(): number; getBody(): any; getHeaders(): Record<string, string> };

  return res;
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

describe("createRateLimiter — request counting", () => {
  it("allows requests up to the limit", () => {
    const limiter = createRateLimiter(3, 60_000);
    const ip = "10.0.0.1";

    for (let i = 0; i < 3; i++) {
      const next = vi.fn();
      limiter(makeReq(ip), makeRes() as any, next);
      expect(next).toHaveBeenCalled();
    }
  });

  it("blocks the request immediately after the limit is reached", () => {
    const limiter = createRateLimiter(3, 60_000);
    const ip = "10.0.0.2";
    const next = vi.fn();

    // Exhaust limit (3 requests)
    for (let i = 0; i < 3; i++) {
      limiter(makeReq(ip), makeRes() as any, next);
    }

    // 4th request should be blocked
    const blockedRes = makeRes();
    const blockedNext = vi.fn();
    limiter(makeReq(ip), blockedRes as any, blockedNext);

    expect(blockedNext).not.toHaveBeenCalled();
    expect(blockedRes.getStatus()).toBe(429);
  });

  it("returns 429 with the provided custom message", () => {
    const limiter = createRateLimiter(1, 60_000, "Custom rate limit message");
    const ip = "10.0.0.3";

    // First request: OK
    limiter(makeReq(ip), makeRes() as any, vi.fn());
    // Second request: blocked
    const res = makeRes();
    limiter(makeReq(ip), res as any, vi.fn());

    expect(res.getStatus()).toBe(429);
    expect(res.getBody().message).toBe("Custom rate limit message");
  });

  it("sets Retry-After header on blocked requests", () => {
    const limiter = createRateLimiter(1, 60_000); // 1 minute window
    const ip = "10.0.0.4";

    limiter(makeReq(ip), makeRes() as any, vi.fn()); // use up limit
    const res = makeRes();
    limiter(makeReq(ip), res as any, vi.fn());

    const retryAfter = Number(res.getHeaders()["Retry-After"]);
    expect(retryAfter).toBeGreaterThan(0);
    expect(retryAfter).toBeLessThanOrEqual(60);
  });
});

describe("createRateLimiter — window behaviour", () => {
  beforeEach(() => vi.useFakeTimers());
  afterEach(() => vi.useRealTimers());

  it("resets the counter after the time window expires", () => {
    const limiter = createRateLimiter(2, 60_000); // 2 req/min
    const ip = "10.0.1.1";

    // Exhaust the limit
    limiter(makeReq(ip), makeRes() as any, vi.fn());
    limiter(makeReq(ip), makeRes() as any, vi.fn());
    const blockedRes = makeRes();
    limiter(makeReq(ip), blockedRes as any, vi.fn());
    expect(blockedRes.getStatus()).toBe(429);

    // Advance past the window
    vi.advanceTimersByTime(61_000);

    // Should be allowed again
    const freshNext = vi.fn();
    limiter(makeReq(ip), makeRes() as any, freshNext);
    expect(freshNext).toHaveBeenCalled();
  });

  it("does not reset prematurely — half-window requests are still blocked", () => {
    const limiter = createRateLimiter(2, 60_000);
    const ip = "10.0.1.2";

    limiter(makeReq(ip), makeRes() as any, vi.fn());
    limiter(makeReq(ip), makeRes() as any, vi.fn());

    // Advance to exactly 50% of the window
    vi.advanceTimersByTime(30_000);

    const prematureNext = vi.fn();
    limiter(makeReq(ip), makeRes() as any, prematureNext);
    expect(prematureNext).not.toHaveBeenCalled();
  });
});

describe("createRateLimiter — IP isolation", () => {
  it("counts requests independently per IP address", () => {
    const limiter = createRateLimiter(1, 60_000);

    const nextA = vi.fn();
    const nextB = vi.fn();

    limiter(makeReq("192.168.1.1"), makeRes() as any, nextA); // exhausts 192.168.1.1
    limiter(makeReq("192.168.1.2"), makeRes() as any, nextB); // different IP — fresh

    expect(nextA).toHaveBeenCalled(); // First request for this IP — OK
    expect(nextB).toHaveBeenCalled(); // First request for different IP — also OK
  });

  it("blocks the correct IP while allowing others to proceed", () => {
    const limiter = createRateLimiter(2, 60_000);
    const exhausted = "10.9.9.9";
    const fresh = "10.9.9.10";

    limiter(makeReq(exhausted), makeRes() as any, vi.fn());
    limiter(makeReq(exhausted), makeRes() as any, vi.fn());

    const blockedRes = makeRes();
    limiter(makeReq(exhausted), blockedRes as any, vi.fn());
    expect(blockedRes.getStatus()).toBe(429);

    // Different IP should still be served
    const allowedNext = vi.fn();
    limiter(makeReq(fresh), makeRes() as any, allowedNext);
    expect(allowedNext).toHaveBeenCalled();
  });
});

describe("createRateLimiter — AUDIT FINDING C5 (in-memory store vulnerability)", () => {
  it("🔴 DOCUMENTED VULNERABILITY: store resets on module re-evaluation (server restart)", () => {
    /**
     * The rate limiter uses a Map() in module scope (closed over by the function).
     * When the Node.js process restarts (as happens frequently on Replit),
     * the Map is garbage-collected and a new empty Map is created.
     *
     * Attack scenario:
     *   1. Attacker makes 5 failed login attempts (limit reached)
     *   2. Attacker triggers a server restart (e.g., by sending a malformed request
     *      that causes an unhandled exception, or by exploiting Replit's hot-reload)
     *   3. Rate limit counter resets to 0
     *   4. Attacker resumes brute-force attack
     *
     * This test simulates the restart by creating a new rate limiter instance.
     * In production, this is equivalent to a process restart.
     *
     * Fix documented in audit report C5:
     *   Use a persistent store: express-rate-limit + rate-limit-postgresql
     *   or Upstash Redis.
     */

    // Simulate: limiter has exhausted its limit
    const preCrashLimiter = createRateLimiter(2, 60_000);
    const ip = "attacker.ip";
    preCrashLimiter(makeReq(ip), makeRes() as any, vi.fn());
    preCrashLimiter(makeReq(ip), makeRes() as any, vi.fn());

    const blockedRes = makeRes();
    preCrashLimiter(makeReq(ip), blockedRes as any, vi.fn());
    expect(blockedRes.getStatus()).toBe(429); // correctly blocked before restart

    // Simulate server restart: new limiter instance = empty Map
    const postRestartLimiter = createRateLimiter(2, 60_000);

    // VULNERABILITY: After restart, the same IP is allowed through again
    const postRestartNext = vi.fn();
    postRestartLimiter(makeReq(ip), makeRes() as any, postRestartNext);
    expect(postRestartNext).toHaveBeenCalled(); // passes! Rate limit bypassed.

    // This assertion documents the vulnerability — not a desired behaviour.
    // When fixed with a persistent store, a new limiter instance would
    // still have the IP's count preserved in the external store.
  });

  it("🔴 DOCUMENTED VULNERABILITY: unknown IP ('unknown') allows bypass when req.ip is undefined", () => {
    /**
     * The limiter uses `req.ip || "unknown"` as the key.
     * If `req.ip` is undefined (e.g., trust proxy not set, running behind certain
     * load balancers, or if an attacker spoofs headers), all requests share the
     * "unknown" bucket — allowing denial-of-service against other users, or
     * collapsing all rate limits into one shared bucket.
     *
     * Additionally, an attacker behind the same NAT as a legitimate user could
     * find their requests blocked even though they haven't made any requests.
     *
     * Fix: use X-Forwarded-For processing via express's trust proxy setting,
     * combined with a persistent store that uses composite keys.
     */
    const limiter = createRateLimiter(1, 60_000);

    // Simulate: req.ip is undefined (trust proxy not configured)
    const reqWithNoIp = { ip: undefined } as unknown as Request;

    limiter(reqWithNoIp, makeRes() as any, vi.fn()); // First request — uses "unknown" key

    // Second request from different client also has no IP — shares "unknown" bucket
    const blockedRes = makeRes();
    limiter(reqWithNoIp, blockedRes as any, vi.fn());

    // Both share the same "unknown" key — second is blocked even though it's a different client
    expect(blockedRes.getStatus()).toBe(429); // Documents the cross-client collision
  });
});
