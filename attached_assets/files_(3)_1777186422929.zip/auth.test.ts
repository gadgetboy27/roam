/**
 * tests/unit/auth.test.ts
 *
 * Unit tests for server/auth.ts — password hashing and comparison.
 *
 * These are pure-function tests with zero external dependencies.
 * They verify cryptographic correctness, timing safety, and
 * edge-case resistance that a production auth system must guarantee.
 */

import { describe, it, expect } from "vitest";
import { hashPassword, comparePassword } from "../../server/auth";

// ---------------------------------------------------------------------------
// hashPassword
// ---------------------------------------------------------------------------

describe("hashPassword", () => {
  it("returns a string in the expected salt:hash format", async () => {
    const result = await hashPassword("correct-horse-battery-staple");

    expect(result).toMatch(/^[0-9a-f]{32}:[0-9a-f]{128}$/);
    // salt = 16 bytes → 32 hex chars
    // key  = 64 bytes → 128 hex chars
  });

  it("produces a different hash on every call — salts are random", async () => {
    const password = "same-password-every-time";
    const [h1, h2, h3] = await Promise.all([
      hashPassword(password),
      hashPassword(password),
      hashPassword(password),
    ]);

    expect(h1).not.toBe(h2);
    expect(h2).not.toBe(h3);
  });

  it("never embeds the plaintext password in the output", async () => {
    const password = "my-secret-p@ssw0rd";
    const hash = await hashPassword(password);

    expect(hash).not.toContain(password);
    expect(hash).not.toContain(Buffer.from(password).toString("base64"));
    expect(hash).not.toContain(Buffer.from(password).toString("hex"));
  });

  it("handles passwords with unicode and special characters", async () => {
    const passwords = [
      "pässwörd-wïth-ümlauts",
      "密码-with-chinese",
      "emoji-🔐-in-password",
      "null-byte-\x00-character",
      "a".repeat(500), // very long password
    ];

    for (const pw of passwords) {
      const hash = await hashPassword(pw);
      expect(hash).toMatch(/^[0-9a-f]{32}:[0-9a-f]{128}$/);
      await expect(comparePassword(pw, hash)).resolves.toBe(true);
    }
  });

  it("minimum-length password (8 chars) hashes successfully", async () => {
    const hash = await hashPassword("8charsPW");
    expect(hash).toMatch(/^[0-9a-f]{32}:/);
  });
});

// ---------------------------------------------------------------------------
// comparePassword
// ---------------------------------------------------------------------------

describe("comparePassword", () => {
  it("returns true when password matches the stored hash", async () => {
    const password = "hunter2-but-secure";
    const hash = await hashPassword(password);
    await expect(comparePassword(password, hash)).resolves.toBe(true);
  });

  it("returns false when password does not match", async () => {
    const hash = await hashPassword("correct-password");
    await expect(comparePassword("wrong-password", hash)).resolves.toBe(false);
  });

  it("returns false for an empty string against a real hash", async () => {
    const hash = await hashPassword("real-password");
    await expect(comparePassword("", hash)).resolves.toBe(false);
  });

  it("🔴 REAL BUG: throws instead of returning false for malformed hash (no colon separator)", async () => {
    /**
     * AUDIT FINDING — server/auth.ts comparePassword()
     *
     * When `stored` has no colon separator, destructuring `[salt, hash]` gives
     * hash = undefined. Buffer.from(undefined, "hex") throws:
     *   TypeError: The first argument must be of type string or an instance of Buffer…
     *
     * This means any code path that calls comparePassword() with unexpected data
     * (e.g., a user whose password column is null/""/corrupted) will throw a 500
     * instead of cleanly returning false.
     *
     * Fix: wrap the body of comparePassword in a try/catch and return false on error.
     * The admin-auth.ts version already does this correctly — user auth.ts does not.
     *
     * Expected behaviour (after fix):
     *   await expect(comparePassword("any-password", "notavalidhash")).resolves.toBe(false);
     */
    await expect(comparePassword("any-password", "notavalidhash")).rejects.toThrow(TypeError);
    // TODO: Once fixed, replace the line above with:
    // await expect(comparePassword("any-password", "notavalidhash")).resolves.toBe(false);
  });

  it("returns false when stored hash has correct format but wrong bytes", async () => {
    const salt = "a".repeat(32);   // 32 hex chars = valid salt
    const fakeHash = "b".repeat(128); // 128 hex chars = valid-looking hash
    const stored = `${salt}:${fakeHash}`;

    await expect(comparePassword("password", stored)).resolves.toBe(false);
  });

  it("is case-sensitive — 'Password' !== 'password'", async () => {
    const hash = await hashPassword("Password");
    await expect(comparePassword("password", hash)).resolves.toBe(false);
    await expect(comparePassword("PASSWORD", hash)).resolves.toBe(false);
    await expect(comparePassword("Password", hash)).resolves.toBe(true);
  });

  it("is timing-safe — comparison time does not short-circuit on first byte mismatch", async () => {
    // We can't easily test timingSafeEqual directly in unit tests,
    // but we can assert the implementation uses it by ensuring that a
    // wildly wrong password doesn't throw a length mismatch error.
    const hash = await hashPassword("some-password");
    // If timingSafeEqual weren't used and lengths differed this would throw.
    await expect(comparePassword("x", hash)).resolves.toBe(false);
    await expect(comparePassword("x".repeat(1000), hash)).resolves.toBe(false);
  });

  it("two different passwords both compare correctly against their own hashes", async () => {
    const pw1 = "first-user-password";
    const pw2 = "second-user-password";
    const [h1, h2] = await Promise.all([hashPassword(pw1), hashPassword(pw2)]);

    // Cross-check: neither password matches the other's hash
    await expect(comparePassword(pw1, h1)).resolves.toBe(true);
    await expect(comparePassword(pw2, h2)).resolves.toBe(true);
    await expect(comparePassword(pw1, h2)).resolves.toBe(false);
    await expect(comparePassword(pw2, h1)).resolves.toBe(false);
  });
});
